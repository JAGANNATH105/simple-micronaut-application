package com.example.controller;

import com.example.controllers.DepartmentController;
import com.example.controllers.EmployeeController;
import com.example.entities.Department;
import com.example.entities.Employee;
import com.example.services.DepartmentService;
import com.example.services.EmployeeService;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;


@MicronautTest
public class DepartmentControllerTest {
    @Inject
    DepartmentService departmentService;

    @Inject
    DepartmentController departmentController;

    @MockBean
            (DepartmentService.class)
    DepartmentService departmentService() {
        return mock(DepartmentService.class);
    };

    @Test
    void getDepartment() {
        when(departmentService.getDepartment()).thenReturn(Stream.of(new Department(),new Department(),new Department()).collect(Collectors.toList()));
        Assertions.assertEquals(3,departmentController.getDepartment().size());
    }
    @Test
    void addDepartment() {

        Department department = new Department(1, "mech");

        when(departmentService.addDepartment(department)).thenReturn("Department Added Successfully");

        String result = departmentController.addDepartment(department);

        assertEquals(result, "Department Added Successfully");
    }
    @Test
    void update() {

        Department department = new Department(1, "mech");

        when(departmentService.update(department,1)).thenReturn(true);

        String result = departmentController.update(department, department.getDepartmentId());

        assertEquals(result, departmentController.update(department, department.getDepartmentId()));

    }
    @Test
    void deleteById() {
        Department department = new Department(1, "mech");
        when(departmentService.deleteById(1)).thenReturn(String.valueOf(department));

        String result = departmentController.deleteById(1);

        assertEquals(result, "Deleted department by id "+department.getDepartmentId());

    }
}
