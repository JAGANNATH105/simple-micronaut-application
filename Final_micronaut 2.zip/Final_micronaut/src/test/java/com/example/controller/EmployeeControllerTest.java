package com.example.controller;

import com.example.controllers.EmployeeController;
import com.example.entities.Department;
import com.example.entities.Employee;
import com.example.services.EmployeeService;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;


@MicronautTest
public class EmployeeControllerTest {
    @Inject
    EmployeeService employeeService;

    @Inject
    EmployeeController employeeController;

    @MockBean
            (EmployeeService.class)
    EmployeeService employeeService() {
        return mock(EmployeeService.class);
    };

    @Test
    void getEmployees() {
        when(employeeService.getEmployees()).thenReturn(Stream.of(new Employee(),new Employee(),new  Employee()).collect(Collectors.toList()));
        Assertions.assertEquals(3,employeeController.getEmployees().size());
    }
    @Test
    void addEmployee() {

        Department department = new Department(1, "mech");
        Employee employee = new Employee("Jaggu",25,40000,"jaggu@gmail.com",new Date(), department);

        when(employeeService.addEmployee(employee)).thenReturn("employee added successfully");

        String result = employeeController.addEmployee(employee);

        assertEquals(result, "employee added successfully");
    }
    @Test
    void update() {

        Department department = new Department(1, "mech");

        Employee employee = new Employee("jaggu",25,35665,"jaggu@gmail.com",new Date(), department);
        employee.setId(1);
        Employee newEmp= new Employee("Jagannath Rasekar",25,40000,"jaggu@gmail.com",new Date(), department);

        when(employeeService.update(employee,1)).thenReturn(employee);

        Employee result = employeeController.update(employee, employee.getId());

        assertEquals(result, employeeController.update(employee, employee.getId()));

    }
    @Test
    void deleteById() {
        Department department = new Department(1, "mech");

        Employee employee = new Employee("jaggu",25,35665,"jaggu@gmail.com",new Date(), department);
        employee.setId(1);

        when(employeeService.deleteById(1)).thenReturn(String.valueOf(employee));

        String result = employeeController.deleteById(1);

        assertEquals(result, "Deleted employee by id "+employee.getId());

    }
}
