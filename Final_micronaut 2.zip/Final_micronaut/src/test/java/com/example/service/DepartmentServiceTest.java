package com.example.service;
import com.example.entities.Department;
import com.example.entities.Employee;
import com.example.repositories.DepartmentRepository;
import com.example.services.DepartmentService;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import java.util.Date;
import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.*;
@MicronautTest
class DepartmentServiceTest {
    @Inject
    DepartmentRepository departmentRepository;
    @Inject
    DepartmentService departmentService;
    @MockBean
            (DepartmentRepository.class)
    DepartmentRepository departmentRepository()
    {
        return mock(DepartmentRepository.class);
    };

    @Test
    void getDepartment() {
//        Department department=new Department(1,"mech");
//        Employee employee=new Employee("pratik",30,12345,"jayhanuman@105gmail.com",new Date(),department);

        when(departmentRepository.findAll()).thenReturn(Stream.of(new Department(),new Department(),new Department()).collect(Collectors.toList()));
//        String result=departmentService.addDepartment(department);
       Assertions.assertEquals(3,departmentService.getDepartment().size());
    }

    @Test
    void addDepartment() {

        Department department = new Department(1, "mech");
        Employee employee = new Employee("jaggu",27,12345,"jaggu@gmail.com",new Date(), department);

        when(departmentRepository.save(department)).thenReturn(department);

        String result = departmentService.addDepartment(department);

        assertEquals(result, "Department Added Successfully");
    }

    @Test
    void update() {

        Department department = new Department(1, "mech");


        when(departmentRepository.findById(1)).thenReturn(Optional.of(department));

        Boolean result = departmentService.update(department, department.getDepartmentId());

        assertEquals(result, departmentService.update(department, department.getDepartmentId()));

    }

    @Test
    void deleteById() {
        Department department = new Department(1, "mech");



        when(departmentRepository.findById(1)).thenReturn(Optional.of(department));

        String result = departmentService.deleteById(1);

        assertEquals(result, "Deleted department by id "+department.getDepartmentId());

    }



}