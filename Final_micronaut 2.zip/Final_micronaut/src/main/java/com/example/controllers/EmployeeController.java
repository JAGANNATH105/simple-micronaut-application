package com.example.controllers;

import com.example.entities.Employee;
import com.example.services.EmailServices;
import com.example.services.EmployeeService;
import io.micronaut.http.annotation.*;
import jakarta.inject.Inject;

import javax.transaction.Transactional;
import java.util.List;

@Controller("/employee")
public class EmployeeController {
@Inject
    EmailServices emailServices;
    @Inject
    EmployeeService employeeService;



    @Get("/show")
    public List<Employee> getEmployees(){
//        System.out.println("emp : "+employeeService.getEmployees());
        return employeeService.getEmployees();
    }

    @Post("/add")
    public String addEmployee(@Body Employee employee){

        return employeeService.addEmployee(employee);
    }

    @Transactional
    @Put("/edit/{id}")
    public Employee update(@Body Employee employee, @PathVariable int id){
        return employeeService.update(employee,id);
    }

    @Delete("/delete/{id}")
    public String deleteById(@PathVariable int id){

        employeeService.deleteById(id);
        return "Deleted employee by id "+id;
    }
}
