package com.example.services;

import com.example.entities.EmailDetails;
import com.example.entities.Employee;
import com.example.repositories.EmployeeRepository;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

@Singleton
public class EmployeeService {

    @Inject
    EmployeeRepository employeeRepository;

    @Inject
    EmailServices emailServices;

    public List<Employee> getEmployees(){
//        System.out.println("service : "+employeeRepository.findAll());
        return employeeRepository.findAll();
    }

    public String addEmployee(Employee employee){
        employeeRepository.save(employee);
        emailServices.sendEmail(new EmailDetails("Employee Alert !!!", "Congratulations "+employee.getName()+", Your Employee Id is "+employee.getId(), employee.getEmail()));

        Object BOOTSTRAP_SERVERS = "localhost:9092";
        String TOPIC = "Employee";

        Properties producerProperties = new Properties();
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


        KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);

        ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Message-"+"Data Inserted"+" "+employee);
        kafkaProducer.send(record);

        kafkaProducer.close();

        return "employee added successfully";
    }


    public Employee update(Employee employee, int id){
        Optional<Employee> optional = employeeRepository.findById(id);
        Employee e = optional.get();

        if(e != null){
            e.setName(employee.getName());
            e.setAge(employee.getAge());
            e.setSal(employee.getSal());
            e.setEmail(employee.getEmail());
            e.setJoiningDate(employee.getJoiningDate());
            e.setDepartment(employee.getDepartment());

            Object BOOTSTRAP_SERVERS = "localhost:9092";
            String TOPIC = "Employee";

            Properties producerProperties = new Properties();
            producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
            producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
            producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


            KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);

            ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Message-"+"Data Updated"+" "+employee);
            kafkaProducer.send(record);

            kafkaProducer.close();
            return employeeRepository.save(e);
        }
        else {
            return null;
        }
    }

    public String deleteById(int id){
        Optional<Employee> employee = employeeRepository.findById(id);
        Employee e = employee.get();
        if(e != null){
            employeeRepository.deleteById(id);
            Object BOOTSTRAP_SERVERS = "localhost:9092";
            String TOPIC = "Employee";

            Properties producerProperties = new Properties();
            producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
            producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
            producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


            KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);

            ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Deleted employee by id "+id+" "+employee);
            kafkaProducer.send(record);

            kafkaProducer.close();
            return "Deleted employee by id "+id;
        }
        else{
            return "Employee with id"+id+" not found";
        }
    }
}
